# SMS SPAM DETECTION USING NATURAL LANGUAGE PROCESSING

## DATA ANALYSIS

## IMPORTING ALL MODULES


```python
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

import pandas as pd
import string
import seaborn as sns
```

    [nltk_data] Downloading package stopwords to
    [nltk_data]     C:\Users\91956\AppData\Roaming\nltk_data...
    [nltk_data]   Package stopwords is already up-to-date!
    C:\Users\91956\AppData\Local\Temp\ipykernel_2336\2674661162.py:8: DeprecationWarning: 
    Pyarrow will become a required dependency of pandas in the next major release of pandas (pandas 3.0),
    (to allow more performant data types, such as the Arrow string type, and better interoperability with other libraries)
    but was not found to be installed on your system.
    If this would cause problems for you,
    please provide us feedback at https://github.com/pandas-dev/pandas/issues/54466
            
      import pandas as pd
    

## READING THE DATASET


```python
import pandas as pd
df = pd.read_csv(r"C:\Users\91956\Downloads\SMSSpamCollection.txt",delimiter="\t",names=["label","message"])
print(df.head(2))
```

      label                                            message
    0   ham  Go until jurong point, crazy.. Available only ...
    1   ham                      Ok lar... Joking wif u oni...
    


```python
df.info()
df.describe()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5572 entries, 0 to 5571
    Data columns (total 2 columns):
     #   Column   Non-Null Count  Dtype 
    ---  ------   --------------  ----- 
     0   label    5572 non-null   object
     1   message  5572 non-null   object
    dtypes: object(2)
    memory usage: 87.2+ KB
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>message</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5572</td>
      <td>5572</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>2</td>
      <td>5169</td>
    </tr>
    <tr>
      <th>top</th>
      <td>ham</td>
      <td>Sorry, I'll call later</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>4825</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby("label").describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="4" halign="left">message</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
    </tr>
    <tr>
      <th>label</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>ham</th>
      <td>4825</td>
      <td>4516</td>
      <td>Sorry, I'll call later</td>
      <td>30</td>
    </tr>
    <tr>
      <th>spam</th>
      <td>747</td>
      <td>653</td>
      <td>Please call our customer service representativ...</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>



#### EXTRACTING FEATURES OF THE DATASET


```python
df["length"]=df["message"].apply(len)
```


```python
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>message</th>
      <th>length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
      <td>Go until jurong point, crazy.. Available only ...</td>
      <td>111</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ham</td>
      <td>Ok lar... Joking wif u oni...</td>
      <td>29</td>
    </tr>
  </tbody>
</table>
</div>



#### THIS WILL HELP THE MODEL RO HAVE MORE FEATURES SO IT CAN PREDICT THE MESAAGE BASED ON ITS LENGTH


```python
sns.histplot(df["length"],bins=30)
```




    <Axes: xlabel='length', ylabel='Count'>




    
![png](output_12_1.png)
    


## MAXIMUM LENGTH OF THE MESSAGE THAT ONE SENT


```python
df["length"].max()
```




    910



## TO KNOW WHAT IS THAT MAXIMUM MESSAGE


```python
df[df["length"]==910]["message"].iloc[0]
```




    "For me the love should start with attraction.i should feel that I need her every time around me.she should be the first thing which comes in my thoughts.I would start the day and end it with her.she should be there every time I dream.love will be then when my every breath has her name.my life should happen around her.my life will be named to her.I would cry for her.will give all my happiness and take all her sorrows.I will be ready to fight with anyone for her.I will be in love when I will be doing the craziest things for her.love will be when I don't have to proove anyone that my girl is the most beautiful lady on the whole planet.I will always be singing praises for her.love will be when I start up making chicken curry and end up makiing sambar.life will be the most beautiful then.will get every morning and thank god for the day because she is with me.I would like to say a lot..will tell later.."




```python
df["length"].min()

```




    2




```python
df[df["length"]==2]["message"].iloc[0]
```




    'Ok'




```python
df.head(1)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>message</th>
      <th>length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
      <td>Go until jurong point, crazy.. Available only ...</td>
      <td>111</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x='label',y='length',data=df)
```




    <Axes: xlabel='label', ylabel='length'>




    
![png](output_20_1.png)
    



```python
df.hist(column='length', by='label',bins=50)
```




    array([<Axes: title={'center': 'ham'}>, <Axes: title={'center': 'spam'}>],
          dtype=object)




    
![png](output_21_1.png)
    


## REMOVING PUNCTUATIONS AND STOPWORDS FROM THE MESSAGES


```python
import nltk
from nltk.corpus import stopwords
import string

def preprocess_text(text):
    words=nltk.word_tokenize(text)
    #remove punctutation
    words=[word for word in words if word not in string.punctuation]
    #remove stopwords
    stop_words=set(stopwords.words('english'))
    words= [word for word in words if word.lower() not in stop_words]
    processed_text=' '.join(words)

    return processed_text
```


```python
mess=('sample message ! Notice : it has a punctiation aksha.')
obj=preprocess_text(mess)
print(obj)
```

    sample message Notice punctiation aksha
    


```python

df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>message</th>
      <th>length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
      <td>Go until jurong point, crazy.. Available only ...</td>
      <td>111</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ham</td>
      <td>Ok lar... Joking wif u oni...</td>
      <td>29</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['message'].head(4).apply(preprocess_text)

```




    0    Go jurong point crazy .. Available bugis n gre...
    1                      Ok lar ... Joking wif u oni ...
    2    Free entry 2 wkly comp win FA Cup final tkts 2...
    3          U dun say early hor ... U c already say ...
    Name: message, dtype: object



## VECTORIZATION


```python
#vectorization
bow_transformer = CountVectorizer(analyzer=preprocess_text).fit(df['message'])
message_bow =bow_transformer.transform(df['message'])
print("shape of sparse matrix{}".format(message_bow.shape))
```

    shape of sparse matrix(5572, 100)
    

## CALCULATING THE SPARSITY


```python
sparsity = (100.0 * message_bow.nnz / (message_bow.shape[0] * message_bow.shape[1]))
print('sparsity: {}'.format(sparsity))
```

    sparsity: 19.860552763819097
    


```python
#convert word count into TFIDF
tfidf_transformer = TfidfTransformer().fit(message_bow)
messages_tfidf = tfidf_transformer.transform(message_bow)
```

## TRAINING THE MODEL


```python
from sklearn.naive_bayes import MultinomialNB
```


```python
model = MultinomialNB().fit(messages_tfidf,df["label"])
```

## PREDICTION


```python
all_predictions= model.predict(messages_tfidf)
pred = pd.DataFrame(data=all_predictions)

pred.head(6)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ham</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ham</td>
    </tr>
    <tr>
      <th>2</th>
      <td>spam</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ham</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ham</td>
    </tr>
    <tr>
      <th>5</th>
      <td>ham</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["label"].head()
```




    0     ham
    1     ham
    2    spam
    3     ham
    4     ham
    Name: label, dtype: object




```python

```
